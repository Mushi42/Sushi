﻿namespace CV
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.maskedTextBox1 = new System.Windows.Forms.MaskedTextBox();
            this.maskedTextBox2 = new System.Windows.Forms.MaskedTextBox();
            this.maskedTextBox3 = new System.Windows.Forms.MaskedTextBox();
            this.maskedTextBox4 = new System.Windows.Forms.MaskedTextBox();
            this.maskedTextBox5 = new System.Windows.Forms.MaskedTextBox();
            this.maskedTextBox6 = new System.Windows.Forms.MaskedTextBox();
            this.maskedTextBox7 = new System.Windows.Forms.MaskedTextBox();
            this.maskedTextBox8 = new System.Windows.Forms.MaskedTextBox();
            this.maskedTextBox9 = new System.Windows.Forms.MaskedTextBox();
            this.maskedTextBox10 = new System.Windows.Forms.MaskedTextBox();
            this.maskedTextBox11 = new System.Windows.Forms.MaskedTextBox();
            this.maskedTextBox12 = new System.Windows.Forms.MaskedTextBox();
            this.maskedTextBox13 = new System.Windows.Forms.MaskedTextBox();
            this.maskedTextBox14 = new System.Windows.Forms.MaskedTextBox();
            this.maskedTextBox15 = new System.Windows.Forms.MaskedTextBox();
            this.maskedTextBox16 = new System.Windows.Forms.MaskedTextBox();
            this.richTextBox2 = new System.Windows.Forms.RichTextBox();
            this.richTextBox3 = new System.Windows.Forms.RichTextBox();
            this.richTextBox4 = new System.Windows.Forms.RichTextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // richTextBox1
            // 
            this.richTextBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.richTextBox1.Font = new System.Drawing.Font("Monotype Corsiva", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox1.Location = new System.Drawing.Point(180, 3);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.ReadOnly = true;
            this.richTextBox1.Size = new System.Drawing.Size(474, 174);
            this.richTextBox1.TabIndex = 1;
            this.richTextBox1.Text = resources.GetString("richTextBox1.Text");
            // 
            // maskedTextBox1
            // 
            this.maskedTextBox1.BackColor = System.Drawing.Color.Black;
            this.maskedTextBox1.ForeColor = System.Drawing.Color.AliceBlue;
            this.maskedTextBox1.Location = new System.Drawing.Point(126, 211);
            this.maskedTextBox1.Name = "maskedTextBox1";
            this.maskedTextBox1.Size = new System.Drawing.Size(201, 20);
            this.maskedTextBox1.TabIndex = 2;
            this.maskedTextBox1.Text = "nomannasir249@gmail.com";
            this.maskedTextBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // maskedTextBox2
            // 
            this.maskedTextBox2.BackColor = System.Drawing.Color.Black;
            this.maskedTextBox2.ForeColor = System.Drawing.Color.AliceBlue;
            this.maskedTextBox2.Location = new System.Drawing.Point(126, 255);
            this.maskedTextBox2.Name = "maskedTextBox2";
            this.maskedTextBox2.Size = new System.Drawing.Size(201, 20);
            this.maskedTextBox2.TabIndex = 3;
            this.maskedTextBox2.Text = "Gul-e-daman , Lahore";
            this.maskedTextBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // maskedTextBox3
            // 
            this.maskedTextBox3.BackColor = System.Drawing.Color.Black;
            this.maskedTextBox3.ForeColor = System.Drawing.Color.AliceBlue;
            this.maskedTextBox3.Location = new System.Drawing.Point(238, 299);
            this.maskedTextBox3.Name = "maskedTextBox3";
            this.maskedTextBox3.Size = new System.Drawing.Size(201, 20);
            this.maskedTextBox3.TabIndex = 4;
            this.maskedTextBox3.Text = "linked.in/nomi112";
            this.maskedTextBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // maskedTextBox4
            // 
            this.maskedTextBox4.BackColor = System.Drawing.Color.Black;
            this.maskedTextBox4.ForeColor = System.Drawing.Color.AliceBlue;
            this.maskedTextBox4.Location = new System.Drawing.Point(333, 211);
            this.maskedTextBox4.Name = "maskedTextBox4";
            this.maskedTextBox4.Size = new System.Drawing.Size(201, 20);
            this.maskedTextBox4.TabIndex = 5;
            this.maskedTextBox4.Text = "+92-303-6256093";
            this.maskedTextBox4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // maskedTextBox5
            // 
            this.maskedTextBox5.BackColor = System.Drawing.Color.Black;
            this.maskedTextBox5.ForeColor = System.Drawing.Color.AliceBlue;
            this.maskedTextBox5.Location = new System.Drawing.Point(333, 255);
            this.maskedTextBox5.Name = "maskedTextBox5";
            this.maskedTextBox5.Size = new System.Drawing.Size(201, 20);
            this.maskedTextBox5.TabIndex = 6;
            this.maskedTextBox5.Text = "plus.google.com/noman12";
            this.maskedTextBox5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // maskedTextBox6
            // 
            this.maskedTextBox6.BackColor = System.Drawing.Color.Lime;
            this.maskedTextBox6.Font = new System.Drawing.Font("Monotype Corsiva", 18F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic) 
                | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.maskedTextBox6.Location = new System.Drawing.Point(23, 330);
            this.maskedTextBox6.Name = "maskedTextBox6";
            this.maskedTextBox6.Size = new System.Drawing.Size(107, 34);
            this.maskedTextBox6.TabIndex = 7;
            this.maskedTextBox6.Text = "Expertise";
            // 
            // maskedTextBox7
            // 
            this.maskedTextBox7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.maskedTextBox7.ForeColor = System.Drawing.Color.AliceBlue;
            this.maskedTextBox7.Location = new System.Drawing.Point(23, 386);
            this.maskedTextBox7.Name = "maskedTextBox7";
            this.maskedTextBox7.Size = new System.Drawing.Size(201, 20);
            this.maskedTextBox7.TabIndex = 8;
            this.maskedTextBox7.Text = "C++";
            this.maskedTextBox7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // maskedTextBox8
            // 
            this.maskedTextBox8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.maskedTextBox8.ForeColor = System.Drawing.Color.AliceBlue;
            this.maskedTextBox8.Location = new System.Drawing.Point(453, 386);
            this.maskedTextBox8.Name = "maskedTextBox8";
            this.maskedTextBox8.Size = new System.Drawing.Size(201, 20);
            this.maskedTextBox8.TabIndex = 9;
            this.maskedTextBox8.Text = "Linux";
            this.maskedTextBox8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // maskedTextBox9
            // 
            this.maskedTextBox9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.maskedTextBox9.ForeColor = System.Drawing.Color.AliceBlue;
            this.maskedTextBox9.Location = new System.Drawing.Point(238, 463);
            this.maskedTextBox9.Name = "maskedTextBox9";
            this.maskedTextBox9.Size = new System.Drawing.Size(201, 20);
            this.maskedTextBox9.TabIndex = 10;
            this.maskedTextBox9.Text = "iOS Devemopment";
            this.maskedTextBox9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // maskedTextBox10
            // 
            this.maskedTextBox10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.maskedTextBox10.ForeColor = System.Drawing.Color.AliceBlue;
            this.maskedTextBox10.Location = new System.Drawing.Point(238, 425);
            this.maskedTextBox10.Name = "maskedTextBox10";
            this.maskedTextBox10.Size = new System.Drawing.Size(201, 20);
            this.maskedTextBox10.TabIndex = 11;
            this.maskedTextBox10.Text = "Android Development";
            this.maskedTextBox10.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // maskedTextBox11
            // 
            this.maskedTextBox11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.maskedTextBox11.ForeColor = System.Drawing.Color.AliceBlue;
            this.maskedTextBox11.Location = new System.Drawing.Point(238, 386);
            this.maskedTextBox11.Name = "maskedTextBox11";
            this.maskedTextBox11.Size = new System.Drawing.Size(201, 20);
            this.maskedTextBox11.TabIndex = 12;
            this.maskedTextBox11.Text = "Microsoft Office";
            this.maskedTextBox11.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // maskedTextBox12
            // 
            this.maskedTextBox12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.maskedTextBox12.ForeColor = System.Drawing.Color.AliceBlue;
            this.maskedTextBox12.Location = new System.Drawing.Point(23, 463);
            this.maskedTextBox12.Name = "maskedTextBox12";
            this.maskedTextBox12.Size = new System.Drawing.Size(201, 20);
            this.maskedTextBox12.TabIndex = 13;
            this.maskedTextBox12.Text = "Python";
            this.maskedTextBox12.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // maskedTextBox13
            // 
            this.maskedTextBox13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.maskedTextBox13.ForeColor = System.Drawing.Color.AliceBlue;
            this.maskedTextBox13.Location = new System.Drawing.Point(23, 425);
            this.maskedTextBox13.Name = "maskedTextBox13";
            this.maskedTextBox13.Size = new System.Drawing.Size(201, 20);
            this.maskedTextBox13.TabIndex = 14;
            this.maskedTextBox13.Text = "C#";
            this.maskedTextBox13.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // maskedTextBox14
            // 
            this.maskedTextBox14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.maskedTextBox14.ForeColor = System.Drawing.Color.AliceBlue;
            this.maskedTextBox14.Location = new System.Drawing.Point(453, 463);
            this.maskedTextBox14.Name = "maskedTextBox14";
            this.maskedTextBox14.Size = new System.Drawing.Size(201, 20);
            this.maskedTextBox14.TabIndex = 15;
            this.maskedTextBox14.Text = "Management";
            this.maskedTextBox14.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // maskedTextBox15
            // 
            this.maskedTextBox15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.maskedTextBox15.ForeColor = System.Drawing.Color.AliceBlue;
            this.maskedTextBox15.Location = new System.Drawing.Point(453, 425);
            this.maskedTextBox15.Name = "maskedTextBox15";
            this.maskedTextBox15.Size = new System.Drawing.Size(201, 20);
            this.maskedTextBox15.TabIndex = 16;
            this.maskedTextBox15.Text = "DB Management";
            this.maskedTextBox15.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // maskedTextBox16
            // 
            this.maskedTextBox16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.maskedTextBox16.Font = new System.Drawing.Font("Monotype Corsiva", 18F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic) 
                | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.maskedTextBox16.Location = new System.Drawing.Point(23, 519);
            this.maskedTextBox16.Name = "maskedTextBox16";
            this.maskedTextBox16.ReadOnly = true;
            this.maskedTextBox16.Size = new System.Drawing.Size(247, 34);
            this.maskedTextBox16.TabIndex = 17;
            this.maskedTextBox16.Text = "Professional Experience";
            // 
            // richTextBox2
            // 
            this.richTextBox2.Location = new System.Drawing.Point(23, 559);
            this.richTextBox2.Name = "richTextBox2";
            this.richTextBox2.ReadOnly = true;
            this.richTextBox2.Size = new System.Drawing.Size(176, 128);
            this.richTextBox2.TabIndex = 18;
            this.richTextBox2.Text = "Senior Developer\n\nCompany : Gradunique\nSalary  : £24,000\nLocation :  Lahore\n\nJob " +
    "Description : \n\nI was a senior Developer there\n";
            // 
            // richTextBox3
            // 
            this.richTextBox3.Location = new System.Drawing.Point(238, 559);
            this.richTextBox3.Name = "richTextBox3";
            this.richTextBox3.ReadOnly = true;
            this.richTextBox3.Size = new System.Drawing.Size(176, 128);
            this.richTextBox3.TabIndex = 19;
            this.richTextBox3.Text = "Senior Project Manager\n\nCompany : Softfords\nSalary  : $124,000\nLocation :  US\n\nJo" +
    "b Description : \n\nI was a senior Project Manager there\n\n";
            // 
            // richTextBox4
            // 
            this.richTextBox4.Location = new System.Drawing.Point(453, 559);
            this.richTextBox4.Name = "richTextBox4";
            this.richTextBox4.ReadOnly = true;
            this.richTextBox4.Size = new System.Drawing.Size(176, 128);
            this.richTextBox4.TabIndex = 20;
            this.richTextBox4.Text = "CEO\n\nCompany : Softfords\nSalary  : $524,000\nLocation : US\n\nJob Description : \n\nI " +
    "am CEO.\n\n";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Black;
            this.button1.Location = new System.Drawing.Point(570, 693);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(84, 29);
            this.button1.TabIndex = 21;
            this.button1.Text = "Next";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox1.Image = global::CV.Properties.Resources._18951209_1360725460682448_243742086071483304_n;
            this.pictureBox1.Location = new System.Drawing.Point(23, 29);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(128, 131);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.ClientSize = new System.Drawing.Size(666, 722);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.richTextBox4);
            this.Controls.Add(this.richTextBox3);
            this.Controls.Add(this.richTextBox2);
            this.Controls.Add(this.maskedTextBox16);
            this.Controls.Add(this.maskedTextBox15);
            this.Controls.Add(this.maskedTextBox14);
            this.Controls.Add(this.maskedTextBox13);
            this.Controls.Add(this.maskedTextBox12);
            this.Controls.Add(this.maskedTextBox11);
            this.Controls.Add(this.maskedTextBox10);
            this.Controls.Add(this.maskedTextBox9);
            this.Controls.Add(this.maskedTextBox8);
            this.Controls.Add(this.maskedTextBox7);
            this.Controls.Add(this.maskedTextBox6);
            this.Controls.Add(this.maskedTextBox5);
            this.Controls.Add(this.maskedTextBox4);
            this.Controls.Add(this.maskedTextBox3);
            this.Controls.Add(this.maskedTextBox2);
            this.Controls.Add(this.maskedTextBox1);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.pictureBox1);
            this.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "CV_Form";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.MaskedTextBox maskedTextBox1;
        private System.Windows.Forms.MaskedTextBox maskedTextBox2;
        private System.Windows.Forms.MaskedTextBox maskedTextBox3;
        private System.Windows.Forms.MaskedTextBox maskedTextBox4;
        private System.Windows.Forms.MaskedTextBox maskedTextBox5;
        private System.Windows.Forms.MaskedTextBox maskedTextBox6;
        private System.Windows.Forms.MaskedTextBox maskedTextBox7;
        private System.Windows.Forms.MaskedTextBox maskedTextBox8;
        private System.Windows.Forms.MaskedTextBox maskedTextBox9;
        private System.Windows.Forms.MaskedTextBox maskedTextBox10;
        private System.Windows.Forms.MaskedTextBox maskedTextBox11;
        private System.Windows.Forms.MaskedTextBox maskedTextBox12;
        private System.Windows.Forms.MaskedTextBox maskedTextBox13;
        private System.Windows.Forms.MaskedTextBox maskedTextBox14;
        private System.Windows.Forms.MaskedTextBox maskedTextBox15;
        private System.Windows.Forms.MaskedTextBox maskedTextBox16;
        private System.Windows.Forms.RichTextBox richTextBox2;
        private System.Windows.Forms.RichTextBox richTextBox3;
        private System.Windows.Forms.RichTextBox richTextBox4;
        private System.Windows.Forms.Button button1;
    }
}

